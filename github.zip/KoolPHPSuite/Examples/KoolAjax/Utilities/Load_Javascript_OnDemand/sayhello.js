﻿function sayhello()
{
	alert("Hello from javascript loaded on-demand");
}
