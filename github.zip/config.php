<?php

// Configuración de la base de datos
$servername = 'yourserver';
$username = 'user';
$password = 'password';
$dbname = 'database';

// Iniciar sesión
session_start();

?>